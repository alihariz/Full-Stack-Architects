package com.mbip.low_carbon_initiatives;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LowCarbonInitiativesApplicationTests {

	@Test
	void contextLoads() {
	}

}
